public interface GameLogic {
    void resetGame();

    boolean checkWin();

    boolean checkDraw();
}
